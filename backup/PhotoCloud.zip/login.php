        <div id="login-box" class="login-popup">
        <fieldset class="textbox">
          <form id="loginForm" class="signin" method="post" action="">
         
            <div id="ok" class="error">*Campos incorrectos</div>
               
                <table width="200" border="0">
                		<th>Login</th>
                  <tr>
                    <td>Correo:</td>
                  </tr>
                  <tr>
                    <td><input id="l_correo" name="l_correo" type="text" class="correo" />
					<div id="msg_l_correo" class="error">*Por favor, introduzca un correo valido</div></td>
                  </tr>
                  <tr>
                    <td>Contraseña:</td>
                  </tr>
                  <tr>
                    <td><input id="l_password" name="l_password" type="password" class="password"/>
					<div id="msg_l_pass" class="error">*Por favor, introduzca una contraseña valida</div></td>
                  </tr>
                  <tr>
                    <td><button id="btnLogin" name="btnLogin"  type="button">Enviar</button></td>
                  </tr>
                </table>
			</form>
		</fieldset>
	</div>